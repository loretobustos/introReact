import React, { Component } from 'react';

class MiComponente extends Component {
  render() {
    return (
      <div>
        <h1>Hola, soy un componente de clase en React para los alumnos de la g41 Desafio LATAM</h1>
        <p>¡Este es un ejemplo de cómo crear un componente de clase en React!</p>
      </div>
    );
  }
}

export default MiComponente;
